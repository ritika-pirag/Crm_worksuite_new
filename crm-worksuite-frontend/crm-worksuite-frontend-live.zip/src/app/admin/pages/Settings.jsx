import { useState, useEffect, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import Card from '../../../components/ui/Card'
import Input from '../../../components/ui/Input'
import Button from '../../../components/ui/Button'
import Badge from '../../../components/ui/Badge'
import { useTheme } from '../../../context/ThemeContext'
import { useLanguage } from '../../../context/LanguageContext'
import { settingsAPI } from '../../../api'
import BaseUrl from '../../../api/baseUrl'
import {
  IoSettings,
  IoChevronDown,
  IoChevronForward,
  IoGlobe,
  IoMail,
  IoDocumentText,
  IoGrid,
  IoMenu,
  IoNotifications,
  IoExtensionPuzzle,
  IoRefresh,
  IoColorPalette,
  IoText,
  IoMoon,
  IoSunny,
  IoCheckmarkCircle,
  IoClose,
  IoImage,
  IoColorFill,
  IoDesktop,
  IoPhonePortrait,
  IoLockClosed,
  IoPeople,
  IoCart,
  IoBuild,
  IoCube,
  IoHome,
  IoShieldCheckmark,
  IoCloudUpload,
  IoServer,
  IoTime,
  IoLanguage,
  IoCodeWorking,
  IoCalendar,
  IoPrint,
  IoDownload,
  IoTrash,
  IoAdd,
  IoCreate,
  IoEye,
  IoEyeOff
} from 'react-icons/io5'

const Settings = () => {
  const navigate = useNavigate()
  const { theme, updateTheme, resetTheme } = useTheme()
  const { changeLanguage } = useLanguage()
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  
  // Sidebar menu state
  const [activeSection, setActiveSection] = useState('app-settings')
  const [activeSubMenu, setActiveSubMenu] = useState('general')
  const [expandedSections, setExpandedSections] = useState({
    'app-settings': true,
    'access-permission': false,
    'client-portal': false,
    'sales-prospects': false,
    'setup': false,
    'plugins': false
  })

  // Settings data state
  const [settings, setSettings] = useState({
    // General Settings
    company_name: '',
    company_email: '',
    company_phone: '',
    company_address: '',
    company_website: '',
    company_logo: '',
    system_name: 'Worksuite CRM',
    default_currency: 'USD',
    default_timezone: 'UTC',
    date_format: 'Y-m-d',
    time_format: 'H:i',
    fiscal_year_start: '01-01',
    session_timeout: 30,
    max_file_size: 10,
    allowed_file_types: 'pdf,doc,docx,xls,xlsx,jpg,jpeg,png',
    
    // Localization
    default_language: 'en',
    date_format_localization: 'Y-m-d',
    time_format_localization: 'H:i',
    timezone_localization: 'UTC',
    currency_symbol_position: 'before',
    
    // Email Settings
    email_from: 'noreply@worksuite.com',
    email_from_name: 'Worksuite CRM',
    smtp_host: '',
    smtp_port: 587,
    smtp_username: '',
    smtp_password: '',
    smtp_encryption: 'tls',
    email_driver: 'smtp',
    
    // UI Options
    theme_mode: 'light',
    font_family: 'Inter, sans-serif',
    primary_color: '#217E45',
    secondary_color: '#76AF88',
    sidebar_style: 'default',
    top_menu_style: 'default',
    
    // Top Menu
    top_menu_items: [],
    top_menu_logo: '',
    top_menu_color: '#ffffff',
    
    // Footer
    footer_text: '© 2024 Worksuite CRM. All rights reserved.',
    footer_links: [],
    footer_color: '#102D2C',
    
    // PWA
    pwa_app_name: 'Worksuite CRM',
    pwa_app_short_name: 'Worksuite',
    pwa_app_description: 'Worksuite CRM Application',
    pwa_app_icon: '',
    pwa_app_color: '#217E45',
    pwa_enabled: false,
    
    // Modules
    module_leads: true,
    module_clients: true,
    module_projects: true,
    module_tasks: true,
    module_invoices: true,
    module_estimates: true,
    module_proposals: true,
    module_payments: true,
    module_expenses: true,
    module_contracts: true,
    module_subscriptions: true,
    module_employees: true,
    module_attendance: true,
    module_time_tracking: true,
    module_events: true,
    module_departments: true,
    module_positions: true,
    module_messages: true,
    module_tickets: true,
    module_documents: true,
    module_reports: true,
    
    // Left Menu
    left_menu_items: [],
    left_menu_style: 'default',
    
    // Notifications
    email_notifications: true,
    sms_notifications: false,
    push_notifications: true,
    notification_sound: true,
    
    // Integration
    google_calendar_enabled: false,
    google_calendar_client_id: '',
    google_calendar_client_secret: '',
    slack_enabled: false,
    slack_webhook_url: '',
    zapier_enabled: false,
    zapier_api_key: '',
    
    // Cron Job
    cron_job_enabled: true,
    cron_job_frequency: 'daily',
    cron_job_last_run: null,
    
    // Updates
    auto_update_enabled: false,
    update_channel: 'stable',
    last_update_check: null,
  })

  // Fetch settings on mount
  useEffect(() => {
    fetchSettings()
  }, [])

  const fetchSettings = async () => {
    try {
      setLoading(true)
      const companyId = localStorage.getItem('companyId') || 1
      const response = await settingsAPI.get({ company_id: companyId })
      if (response.data.success) {
        const settingsData = response.data.data || []
        const settingsObj = {}
        
        // Transform settings array to object
        settingsData.forEach(setting => {
          try {
            // Try to parse JSON values
            if (setting.setting_value && (setting.setting_value.startsWith('{') || setting.setting_value.startsWith('['))) {
              settingsObj[setting.setting_key] = JSON.parse(setting.setting_value)
            } else {
              settingsObj[setting.setting_key] = setting.setting_value
            }
          } catch (e) {
            settingsObj[setting.setting_key] = setting.setting_value
          }
        })
        
        // Merge with defaults
        setSettings(prev => ({
          ...prev,
          ...settingsObj,
          // Ensure boolean values
          email_notifications: settingsObj.email_notifications === 'true' || settingsObj.email_notifications === true,
          sms_notifications: settingsObj.sms_notifications === 'true' || settingsObj.sms_notifications === true,
          push_notifications: settingsObj.push_notifications === 'true' || settingsObj.push_notifications === true,
          notification_sound: settingsObj.notification_sound === 'true' || settingsObj.notification_sound === true,
          pwa_enabled: settingsObj.pwa_enabled === 'true' || settingsObj.pwa_enabled === true,
          auto_update_enabled: settingsObj.auto_update_enabled === 'true' || settingsObj.auto_update_enabled === true,
          google_calendar_enabled: settingsObj.google_calendar_enabled === 'true' || settingsObj.google_calendar_enabled === true,
          slack_enabled: settingsObj.slack_enabled === 'true' || settingsObj.slack_enabled === true,
          zapier_enabled: settingsObj.zapier_enabled === 'true' || settingsObj.zapier_enabled === true,
          cron_job_enabled: settingsObj.cron_job_enabled === 'true' || settingsObj.cron_job_enabled === true,
          // Module settings
          module_leads: settingsObj.module_leads !== 'false' && settingsObj.module_leads !== false,
          module_clients: settingsObj.module_clients !== 'false' && settingsObj.module_clients !== false,
          module_projects: settingsObj.module_projects !== 'false' && settingsObj.module_projects !== false,
          module_tasks: settingsObj.module_tasks !== 'false' && settingsObj.module_tasks !== false,
          module_invoices: settingsObj.module_invoices !== 'false' && settingsObj.module_invoices !== false,
          module_estimates: settingsObj.module_estimates !== 'false' && settingsObj.module_estimates !== false,
          module_proposals: settingsObj.module_proposals !== 'false' && settingsObj.module_proposals !== false,
          module_payments: settingsObj.module_payments !== 'false' && settingsObj.module_payments !== false,
          module_expenses: settingsObj.module_expenses !== 'false' && settingsObj.module_expenses !== false,
          module_contracts: settingsObj.module_contracts !== 'false' && settingsObj.module_contracts !== false,
          module_subscriptions: settingsObj.module_subscriptions !== 'false' && settingsObj.module_subscriptions !== false,
          module_employees: settingsObj.module_employees !== 'false' && settingsObj.module_employees !== false,
          module_attendance: settingsObj.module_attendance !== 'false' && settingsObj.module_attendance !== false,
          module_time_tracking: settingsObj.module_time_tracking !== 'false' && settingsObj.module_time_tracking !== false,
          module_events: settingsObj.module_events !== 'false' && settingsObj.module_events !== false,
          module_departments: settingsObj.module_departments !== 'false' && settingsObj.module_departments !== false,
          module_positions: settingsObj.module_positions !== 'false' && settingsObj.module_positions !== false,
          module_messages: settingsObj.module_messages !== 'false' && settingsObj.module_messages !== false,
          module_tickets: settingsObj.module_tickets !== 'false' && settingsObj.module_tickets !== false,
          module_documents: settingsObj.module_documents !== 'false' && settingsObj.module_documents !== false,
          module_reports: settingsObj.module_reports !== 'false' && settingsObj.module_reports !== false,
        }))

        // Load theme settings
        if (settingsObj.theme_mode) {
          updateTheme({ mode: settingsObj.theme_mode })
        }
        if (settingsObj.font_family) {
          updateTheme({ fontFamily: settingsObj.font_family })
        }
        if (settingsObj.primary_color) {
          updateTheme({ primaryAccent: settingsObj.primary_color })
        }
        if (settingsObj.secondary_color) {
          updateTheme({ secondaryAccent: settingsObj.secondary_color })
        }
      }
    } catch (error) {
      console.error('Error fetching settings:', error)
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (field, value) => {
    setSettings(prev => ({ ...prev, [field]: value }))
  }

  const handleSave = async (category = null) => {
    try {
      setSaving(true)
      
      // Prepare settings to save based on category or all
      let settingsToSave = []
      
      if (category) {
        // Save only settings for specific category
        const categoryPrefixes = {
          // General Settings page includes: General, UI Options, Top Menu, Footer, PWA tabs
          'general': [
            'company_', 'system_', 'default_', 'date_', 'time_', 'fiscal_', 'session_', 'max_', 'allowed_',
            'theme_mode', 'font_family', 'primary_color', 'secondary_color', 'sidebar_style', 'top_menu_style',
            'top_menu_', 'footer_', 'pwa_'
          ],
          'localization': ['default_language', 'date_format_localization', 'time_format_localization', 'timezone_localization', 'currency_symbol_position'],
          'email': ['email_', 'smtp_'],
          'ui-options': ['theme_mode', 'font_family', 'primary_color', 'secondary_color', 'sidebar_style', 'top_menu_style'],
          'top-menu': ['top_menu_'],
          'footer': ['footer_'],
          'pwa': ['pwa_'],
          'modules': ['module_'],
          'left-menu': ['left_menu_'],
          'notifications': ['notification_', 'email_notifications', 'sms_notifications', 'push_notifications'],
          'integration': ['google_calendar_', 'slack_', 'zapier_'],
          'cron-job': ['cron_job_'],
          'updates': ['auto_update_', 'update_', 'last_update_']
        }
        
        const prefixes = categoryPrefixes[category] || []
        Object.keys(settings).forEach(key => {
          if (prefixes.some(prefix => key.startsWith(prefix))) {
            settingsToSave.push({
              setting_key: key,
              setting_value: typeof settings[key] === 'object' ? JSON.stringify(settings[key]) : String(settings[key])
            })
          }
        })
      } else {
        // Save all settings
        Object.keys(settings).forEach(key => {
          settingsToSave.push({
            setting_key: key,
            setting_value: typeof settings[key] === 'object' ? JSON.stringify(settings[key]) : String(settings[key])
          })
        })
      }

      if (settingsToSave.length === 0) {
        alert('No settings to save')
        return
      }

      // Use bulk update API
      const companyId = localStorage.getItem('companyId') || 1
      const response = await settingsAPI.bulkUpdate(settingsToSave, { company_id: companyId })
      
      if (response.data.success) {
        // Apply theme changes immediately without page reload
        if (settings.theme_mode) {
          updateTheme({ mode: settings.theme_mode })
        }
        if (settings.primary_color) {
          updateTheme({ primaryAccent: settings.primary_color })
        }
        if (settings.secondary_color) {
          updateTheme({ secondaryAccent: settings.secondary_color })
        }
        if (settings.font_family) {
          updateTheme({ fontFamily: settings.font_family })
        }
        
        alert(category ? `${category} settings saved successfully!` : 'All settings saved successfully!')
        await fetchSettings()
      } else {
        alert(response.data.error || 'Failed to save settings')
      }
    } catch (error) {
      console.error('Error saving settings:', error)
      const errorMessage = error.response?.data?.error || error.message || 'Failed to save settings'
      alert(`Error: ${errorMessage}`)
    } finally {
      setSaving(false)
    }
  }

  const handleLogoUpload = async (e, type = 'logo') => {
    const file = e.target.files[0]
    if (!file) return

    if (!file.type.startsWith('image/')) {
      alert('Please select an image file')
      return
    }

    if (file.size > 5 * 1024 * 1024) {
      alert('File size must be less than 5MB')
      return
    }

    try {
      setSaving(true)
      const formData = new FormData()
      formData.append('logo', file)
      formData.append('setting_key', type === 'logo' ? 'company_logo' : type)

      const response = await settingsAPI.update(formData, {
        headers: {
          'Content-Type': 'multipart/form-data'
        }
      })

      if (response.data.success) {
        const previewUrl = URL.createObjectURL(file)
        handleChange(type === 'logo' ? 'company_logo' : type, previewUrl)
        alert(`${type === 'logo' ? 'Logo' : 'Image'} uploaded successfully!`)
      } else {
        alert(response.data.error || `Failed to upload ${type}`)
      }
    } catch (error) {
      console.error(`Error uploading ${type}:`, error)
      alert(error.response?.data?.error || `Failed to upload ${type}`)
    } finally {
      setSaving(false)
    }
  }

  const toggleSection = (section) => {
    setExpandedSections(prev => ({
      ...prev,
      [section]: !prev[section]
    }))
  }

  const menuItems = [
    {
      id: 'app-settings',
      label: 'App Settings',
      icon: IoSettings,
      children: [
        { id: 'general', label: 'General', icon: IoSettings },
        { id: 'localization', label: 'Localization', icon: IoLanguage },
        { id: 'email', label: 'Email', icon: IoMail },
        { id: 'email-templates', label: 'Email Templates', icon: IoDocumentText },
        { id: 'modules', label: 'Modules', icon: IoGrid },
        { id: 'left-menu', label: 'Left Menu', icon: IoMenu },
        { id: 'notifications', label: 'Notifications', icon: IoNotifications },
        { id: 'integration', label: 'Integration', icon: IoExtensionPuzzle },
        { id: 'cron-job', label: 'Cron Job', icon: IoTime },
        { id: 'updates', label: 'Updates', icon: IoCloudUpload },
      ]
    },
    {
      id: 'access-permission',
      label: 'Access Permission',
      icon: IoLockClosed,
      children: [
        { id: 'access-permission', label: 'Roles & Permissions', icon: IoShieldCheckmark },
      ]
    },
    {
      id: 'client-portal',
      label: 'Client Portal',
      icon: IoPeople,
      children: [
        { id: 'client-portal', label: 'Portal Settings', icon: IoPeople },
      ]
    },
    {
      id: 'sales-prospects',
      label: 'Sales & Prospects',
      icon: IoCart,
      children: [
        { id: 'sales-prospects', label: 'Pipeline Settings', icon: IoCart },
      ]
    },
    {
      id: 'setup',
      label: 'Setup',
      icon: IoBuild,
      children: [
        { id: 'setup', label: 'System Setup', icon: IoBuild },
      ]
    },
    {
      id: 'plugins',
      label: 'Plugins',
      icon: IoCube,
      children: [
        { id: 'plugins', label: 'Manage Plugins', icon: IoCube },
      ]
    }
  ]

  const renderContent = () => {
    switch (activeSubMenu) {
      case 'general':
        return <GeneralSettings settings={settings} handleChange={handleChange} handleLogoUpload={handleLogoUpload} />
      case 'localization':
        return <LocalizationSettings settings={settings} handleChange={handleChange} onLanguageChange={changeLanguage} />
      case 'email':
        return <EmailSettings settings={settings} handleChange={handleChange} />
      case 'email-templates':
        return <EmailTemplatesSettings settings={settings} handleChange={handleChange} />
      case 'modules':
        return <ModulesSettings settings={settings} handleChange={handleChange} />
      case 'left-menu':
        return <LeftMenuSettings settings={settings} handleChange={handleChange} />
      case 'notifications':
        return <NotificationsSettings settings={settings} handleChange={handleChange} />
      case 'integration':
        return <IntegrationSettings settings={settings} handleChange={handleChange} />
      case 'cron-job':
        return <CronJobSettings settings={settings} handleChange={handleChange} />
      case 'updates':
        return <UpdatesSettings settings={settings} handleChange={handleChange} />
      case 'access-permission':
        return <AccessPermissionSettings settings={settings} handleChange={handleChange} />
      case 'client-portal':
        return <ClientPortalSettings settings={settings} handleChange={handleChange} />
      case 'sales-prospects':
        return <SalesProspectsSettings settings={settings} handleChange={handleChange} />
      case 'setup':
        return <SetupSettings settings={settings} handleChange={handleChange} />
      case 'plugins':
        return <PluginsSettings settings={settings} handleChange={handleChange} />
      default:
        return <GeneralSettings settings={settings} handleChange={handleChange} handleLogoUpload={handleLogoUpload} />
    }
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-accent mx-auto"></div>
          <p className="mt-4 text-secondary-text">Loading settings...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex flex-col lg:flex-row gap-4 h-[calc(100vh-120px)]">
      {/* Left Sidebar Menu */}
      <div className="w-full lg:w-64 bg-white rounded-lg shadow-sm border border-gray-200 overflow-y-auto">
        <div className="p-4 border-b border-gray-200">
          <h2 className="text-lg font-semibold text-primary-text">Settings</h2>
        </div>
        <nav className="p-2">
          {menuItems.map((item) => (
            <div key={item.id}>
              <button
                onClick={() => {
                  if (item.children.length > 0) {
                    toggleSection(item.id)
                  } else {
                    setActiveSection(item.id)
                    setActiveSubMenu(item.id)
                  }
                }}
                className={`w-full flex items-center justify-between px-3 py-2.5 rounded-lg transition-colors mb-1 ${
                  activeSection === item.id
                    ? 'bg-primary-accent/10 text-primary-accent'
                    : 'text-primary-text hover:bg-gray-100'
                }`}
              >
                <div className="flex items-center gap-2">
                  <item.icon size={18} />
                  <span className="text-sm font-medium">{item.label}</span>
                </div>
                {item.children.length > 0 && (
                  expandedSections[item.id] ? <IoChevronDown size={16} /> : <IoChevronForward size={16} />
                )}
              </button>
              
              {item.children.length > 0 && expandedSections[item.id] && (
                <div className="ml-6 mt-1 space-y-1">
                  {item.children.map((child) => (
                    <button
                      key={child.id}
                      onClick={() => {
                        setActiveSection(item.id)
                        setActiveSubMenu(child.id)
                      }}
                      className={`w-full flex items-center gap-2 px-3 py-2 rounded-lg transition-colors text-sm ${
                        activeSubMenu === child.id
                          ? 'bg-primary-accent text-white'
                          : 'text-secondary-text hover:bg-gray-50'
                      }`}
                    >
                      <child.icon size={16} />
                      <span>{child.label}</span>
                    </button>
                  ))}
                </div>
              )}
            </div>
          ))}
        </nav>
      </div>

      {/* Main Content Area */}
      <div className="flex-1 overflow-y-auto">
        <Card className="p-6">
          {renderContent()}
          <div className="flex justify-end gap-3 mt-6 pt-6 border-t border-gray-200">
            <Button
              variant="outline"
              onClick={() => fetchSettings()}
              disabled={saving}
            >
              Cancel
            </Button>
            <Button
              variant="primary"
              onClick={() => handleSave(activeSubMenu)}
              disabled={saving}
            >
              {saving ? 'Saving...' : 'Save Changes'}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  )
}

// General Settings Component
const GeneralSettings = ({ settings, handleChange, handleLogoUpload }) => {
  const [activeTab, setActiveTab] = useState('general')
  
  const tabs = [
    { id: 'general', label: 'General Settings' },
    { id: 'ui-options', label: 'UI Options' },
    { id: 'top-menu', label: 'Top Menu' },
    { id: 'footer', label: 'Footer' },
    { id: 'pwa', label: 'PWA' }
  ]

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-primary-text mb-2">General Settings</h1>
        <p className="text-secondary-text">Configure general application settings</p>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6 border-b border-gray-200">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`px-4 py-2 font-medium text-sm border-b-2 transition-colors ${
              activeTab === tab.id
                ? 'border-primary-accent text-primary-accent'
                : 'border-transparent text-secondary-text hover:text-primary-text'
            }`}
          >
            {tab.label}
          </button>
        ))}
      </div>

      {/* Tab Content */}
      {activeTab === 'general' && (
        <div className="space-y-6">
          <div>
            <h3 className="text-lg font-semibold text-primary-text mb-4">Company Information</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="Company Name"
                value={settings.company_name || ''}
                onChange={(e) => handleChange('company_name', e.target.value)}
                placeholder="Enter company name"
              />
              <Input
                label="Company Email"
                type="email"
                value={settings.company_email || ''}
                onChange={(e) => handleChange('company_email', e.target.value)}
                placeholder="company@example.com"
              />
              <Input
                label="Company Phone"
                value={settings.company_phone || ''}
                onChange={(e) => handleChange('company_phone', e.target.value)}
                placeholder="+1 234 567 8900"
              />
              <Input
                label="Company Website"
                value={settings.company_website || ''}
                onChange={(e) => handleChange('company_website', e.target.value)}
                placeholder="https://example.com"
              />
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-primary-text mb-2">Company Address</label>
                <textarea
                  value={settings.company_address || ''}
                  onChange={(e) => handleChange('company_address', e.target.value)}
                  rows={3}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                  placeholder="Enter company address"
                />
              </div>
              <div className="md:col-span-2">
                <label className="block text-sm font-medium text-primary-text mb-2">Company Logo</label>
                <div className="flex items-center gap-4">
                  <input
                    type="file"
                    accept="image/*"
                    onChange={(e) => handleLogoUpload(e, 'logo')}
                    className="flex-1 px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                  />
                  {settings.company_logo && (
                    <img
                      src={settings.company_logo.startsWith('http') || settings.company_logo.startsWith('blob:')
                        ? settings.company_logo
                        : `${BaseUrl}${settings.company_logo.startsWith('/') ? '' : '/'}${settings.company_logo}`
                      }
                      alt="Company Logo"
                      className="h-16 w-auto object-contain rounded-lg border border-gray-200 p-2 bg-gray-50"
                      onError={(e) => e.target.style.display = 'none'}
                    />
                  )}
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-200 pt-6">
            <h3 className="text-lg font-semibold text-primary-text mb-4">System Settings</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Input
                label="System Name"
                value={settings.system_name || ''}
                onChange={(e) => handleChange('system_name', e.target.value)}
                placeholder="Worksuite CRM"
              />
              <div>
                <label className="block text-sm font-medium text-primary-text mb-2">Default Currency</label>
                <select
                  value={settings.default_currency || 'USD'}
                  onChange={(e) => handleChange('default_currency', e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                >
                  <option value="USD">USD ($)</option>
                  <option value="EUR">EUR (€)</option>
                  <option value="GBP">GBP (£)</option>
                  <option value="INR">INR (₹)</option>
                  <option value="AED">AED (د.إ)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-primary-text mb-2">Default Timezone</label>
                <select
                  value={settings.default_timezone || 'UTC'}
                  onChange={(e) => handleChange('default_timezone', e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                >
                  <option value="UTC">UTC</option>
                  <option value="America/New_York">America/New_York</option>
                  <option value="Europe/London">Europe/London</option>
                  <option value="Asia/Kolkata">Asia/Kolkata</option>
                  <option value="Asia/Dubai">Asia/Dubai</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-primary-text mb-2">Date Format</label>
                <select
                  value={settings.date_format || 'Y-m-d'}
                  onChange={(e) => handleChange('date_format', e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                >
                  <option value="Y-m-d">YYYY-MM-DD</option>
                  <option value="m/d/Y">MM/DD/YYYY</option>
                  <option value="d/m/Y">DD/MM/YYYY</option>
                  <option value="d-m-Y">DD-MM-YYYY</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-primary-text mb-2">Time Format</label>
                <select
                  value={settings.time_format || 'H:i'}
                  onChange={(e) => handleChange('time_format', e.target.value)}
                  className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                >
                  <option value="H:i">24 Hour (HH:MM)</option>
                  <option value="h:i A">12 Hour (HH:MM AM/PM)</option>
                </select>
              </div>
              <Input
                label="Session Timeout (minutes)"
                type="number"
                value={settings.session_timeout || 30}
                onChange={(e) => handleChange('session_timeout', parseInt(e.target.value))}
                min="5"
                max="480"
              />
              <Input
                label="Max File Size (MB)"
                type="number"
                value={settings.max_file_size || 10}
                onChange={(e) => handleChange('max_file_size', parseInt(e.target.value))}
                min="1"
                max="100"
              />
              <Input
                label="Allowed File Types"
                value={settings.allowed_file_types || ''}
                onChange={(e) => handleChange('allowed_file_types', e.target.value)}
                placeholder="pdf,doc,docx,jpg,png"
              />
            </div>
          </div>
        </div>
      )}

      {activeTab === 'ui-options' && (
        <UIOptionsTab settings={settings} handleChange={handleChange} />
      )}

      {activeTab === 'top-menu' && (
        <TopMenuTab settings={settings} handleChange={handleChange} />
      )}

      {activeTab === 'footer' && (
        <FooterTab settings={settings} handleChange={handleChange} />
      )}

      {activeTab === 'pwa' && (
        <PWATab settings={settings} handleChange={handleChange} handleLogoUpload={handleLogoUpload} />
      )}
    </div>
  )
}

// UI Options Tab Component
const UIOptionsTab = ({ settings, handleChange }) => {
  const { theme, updateTheme } = useTheme()
  
  const fontOptions = [
    { value: '-apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", sans-serif', label: 'System Default' },
    { value: 'Inter, sans-serif', label: 'Inter' },
    { value: 'Poppins, sans-serif', label: 'Poppins' },
    { value: 'Roboto, sans-serif', label: 'Roboto' },
    { value: 'Open Sans, sans-serif', label: 'Open Sans' },
    { value: 'Lato, sans-serif', label: 'Lato' },
    { value: 'Montserrat, sans-serif', label: 'Montserrat' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-primary-text mb-4">Theme Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Theme Mode</label>
            <div className="flex gap-2">
              <button
                onClick={() => {
                  handleChange('theme_mode', 'light')
                  updateTheme({ mode: 'light' })
                }}
                className={`flex-1 px-4 py-2 rounded-lg border-2 transition-colors ${
                  (settings.theme_mode || 'light') === 'light'
                    ? 'border-primary-accent bg-primary-accent/10 text-primary-accent'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <IoSunny size={18} className="mx-auto mb-1" />
                Light
              </button>
              <button
                onClick={() => {
                  handleChange('theme_mode', 'dark')
                  updateTheme({ mode: 'dark' })
                }}
                className={`flex-1 px-4 py-2 rounded-lg border-2 transition-colors ${
                  settings.theme_mode === 'dark'
                    ? 'border-primary-accent bg-primary-accent/10 text-primary-accent'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <IoMoon size={18} className="mx-auto mb-1" />
                Dark
              </button>
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Font Family</label>
            <select
              value={settings.font_family || fontOptions[0].value}
              onChange={(e) => {
                handleChange('font_family', e.target.value)
                updateTheme({ fontFamily: e.target.value })
              }}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
              style={{ fontFamily: settings.font_family || fontOptions[0].value }}
            >
              {fontOptions.map((font) => (
                <option key={font.value} value={font.value}>
                  {font.label}
                </option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Primary Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.primary_color || '#217E45'}
                onChange={(e) => {
                  handleChange('primary_color', e.target.value)
                  updateTheme({ primaryAccent: e.target.value })
                }}
                className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
              />
              <Input
                value={settings.primary_color || '#217E45'}
                onChange={(e) => {
                  handleChange('primary_color', e.target.value)
                  updateTheme({ primaryAccent: e.target.value })
                }}
                placeholder="#217E45"
                className="flex-1"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Secondary Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.secondary_color || '#76AF88'}
                onChange={(e) => {
                  handleChange('secondary_color', e.target.value)
                  updateTheme({ secondaryAccent: e.target.value })
                }}
                className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
              />
              <Input
                value={settings.secondary_color || '#76AF88'}
                onChange={(e) => {
                  handleChange('secondary_color', e.target.value)
                  updateTheme({ secondaryAccent: e.target.value })
                }}
                placeholder="#76AF88"
                className="flex-1"
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Sidebar Style</label>
            <select
              value={settings.sidebar_style || 'default'}
              onChange={(e) => handleChange('sidebar_style', e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
            >
              <option value="default">Default</option>
              <option value="compact">Compact</option>
              <option value="icon-only">Icon Only</option>
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Top Menu Style</label>
            <select
              value={settings.top_menu_style || 'default'}
              onChange={(e) => handleChange('top_menu_style', e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
            >
              <option value="default">Default</option>
              <option value="centered">Centered</option>
              <option value="minimal">Minimal</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  )
}

// Top Menu Tab Component
const TopMenuTab = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-primary-text mb-4">Top Menu Configuration</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Top Menu Logo</label>
            <input
              type="file"
              accept="image/*"
              onChange={(e) => {
                const file = e.target.files[0]
                if (file) {
                  const reader = new FileReader()
                  reader.onload = (e) => handleChange('top_menu_logo', e.target.result)
                  reader.readAsDataURL(file)
                }
              }}
              className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
            />
            {settings.top_menu_logo && (
              <img src={settings.top_menu_logo} alt="Top Menu Logo" className="h-12 mt-2" />
            )}
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Top Menu Background Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.top_menu_color || '#ffffff'}
                onChange={(e) => handleChange('top_menu_color', e.target.value)}
                className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
              />
              <Input
                value={settings.top_menu_color || '#ffffff'}
                onChange={(e) => handleChange('top_menu_color', e.target.value)}
                placeholder="#ffffff"
                className="flex-1"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Footer Tab Component
const FooterTab = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-primary-text mb-4">Footer Configuration</h3>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Footer Text</label>
            <textarea
              value={settings.footer_text || ''}
              onChange={(e) => handleChange('footer_text', e.target.value)}
              rows={3}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
              placeholder="© 2024 Worksuite CRM. All rights reserved."
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Footer Background Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.footer_color || '#102D2C'}
                onChange={(e) => handleChange('footer_color', e.target.value)}
                className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
              />
              <Input
                value={settings.footer_color || '#102D2C'}
                onChange={(e) => handleChange('footer_color', e.target.value)}
                placeholder="#102D2C"
                className="flex-1"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// PWA Tab Component
const PWATab = ({ settings, handleChange, handleLogoUpload }) => {
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-primary-text mb-4">Progressive Web App (PWA) Settings</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <label className="flex items-center gap-2 mb-2">
              <input
                type="checkbox"
                checked={settings.pwa_enabled || false}
                onChange={(e) => handleChange('pwa_enabled', e.target.checked)}
                className="w-4 h-4 text-primary-accent rounded focus:ring-primary-accent"
              />
              <span className="text-sm font-medium text-primary-text">Enable PWA</span>
            </label>
          </div>
          <Input
            label="App Name"
            value={settings.pwa_app_name || ''}
            onChange={(e) => handleChange('pwa_app_name', e.target.value)}
            placeholder="Worksuite CRM"
          />
          <Input
            label="App Short Name"
            value={settings.pwa_app_short_name || ''}
            onChange={(e) => handleChange('pwa_app_short_name', e.target.value)}
            placeholder="Worksuite"
          />
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-primary-text mb-2">App Description</label>
            <textarea
              value={settings.pwa_app_description || ''}
              onChange={(e) => handleChange('pwa_app_description', e.target.value)}
              rows={2}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
              placeholder="Worksuite CRM Application"
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-primary-text mb-2">App Icon (192×192)</label>
            <div className="flex items-center gap-4">
              <div className="flex-1">
                <input
                  type="file"
                  accept="image/*"
                  onChange={(e) => handleLogoUpload(e, 'pwa_app_icon')}
                  className="w-full px-4 py-2 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
                />
                <p className="text-xs text-secondary-text mt-1">Recommended size: 192×192 pixels</p>
              </div>
              {settings.pwa_app_icon && (
                <div className="relative">
                  <img
                    src={settings.pwa_app_icon.startsWith('http') || settings.pwa_app_icon.startsWith('blob:')
                      ? settings.pwa_app_icon
                      : `${BaseUrl}${settings.pwa_app_icon.startsWith('/') ? '' : '/'}${settings.pwa_app_icon}`
                    }
                    alt="PWA Icon"
                    className="w-24 h-24 object-contain rounded-lg border border-gray-200 p-2 bg-gray-50"
                    onError={(e) => e.target.style.display = 'none'}
                  />
                </div>
              )}
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">App Theme Color</label>
            <div className="flex items-center gap-2">
              <input
                type="color"
                value={settings.pwa_app_color || '#217E45'}
                onChange={(e) => handleChange('pwa_app_color', e.target.value)}
                className="w-12 h-12 rounded-lg border-2 border-gray-300 cursor-pointer"
              />
              <Input
                value={settings.pwa_app_color || '#217E45'}
                onChange={(e) => handleChange('pwa_app_color', e.target.value)}
                placeholder="#217E45"
                className="flex-1"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}

// Localization Settings Component
const LocalizationSettings = ({ settings, handleChange, onLanguageChange }) => {
  const handleLanguageSelect = (e) => {
    const newLang = e.target.value
    handleChange('default_language', newLang)
    // Apply language change immediately
    if (onLanguageChange) {
      onLanguageChange(newLang)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Localization Settings</h1>
        <p className="text-secondary-text">Configure language and regional settings</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Default Language</label>
          <select
            value={settings.default_language || 'en'}
            onChange={handleLanguageSelect}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="en">English</option>
            <option value="es">Spanish (Español)</option>
            <option value="fr">French (Français)</option>
            <option value="de">German (Deutsch)</option>
            <option value="ar">Arabic (العربية)</option>
            <option value="hi">Hindi (हिंदी)</option>
          </select>
          <p className="text-xs text-secondary-text mt-1">Language will be applied immediately</p>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Date Format</label>
          <select
            value={settings.date_format_localization || 'Y-m-d'}
            onChange={(e) => handleChange('date_format_localization', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="Y-m-d">YYYY-MM-DD</option>
            <option value="m/d/Y">MM/DD/YYYY</option>
            <option value="d/m/Y">DD/MM/YYYY</option>
            <option value="d-m-Y">DD-MM-YYYY</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Time Format</label>
          <select
            value={settings.time_format_localization || 'H:i'}
            onChange={(e) => handleChange('time_format_localization', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="H:i">24 Hour (HH:MM)</option>
            <option value="h:i A">12 Hour (HH:MM AM/PM)</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Timezone</label>
          <select
            value={settings.timezone_localization || 'UTC'}
            onChange={(e) => handleChange('timezone_localization', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="UTC">UTC</option>
            <option value="America/New_York">America/New_York</option>
            <option value="Europe/London">Europe/London</option>
            <option value="Asia/Kolkata">Asia/Kolkata</option>
            <option value="Asia/Dubai">Asia/Dubai</option>
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Currency Symbol Position</label>
          <select
            value={settings.currency_symbol_position || 'before'}
            onChange={(e) => handleChange('currency_symbol_position', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="before">Before Amount ($100)</option>
            <option value="after">After Amount (100$)</option>
          </select>
        </div>
      </div>
    </div>
  )
}

// Email Settings Component
const EmailSettings = ({ settings, handleChange }) => {
  const [showPassword, setShowPassword] = useState(false)
  
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Email Settings</h1>
        <p className="text-secondary-text">Configure email server settings</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Email Driver</label>
          <select
            value={settings.email_driver || 'smtp'}
            onChange={(e) => handleChange('email_driver', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="smtp">SMTP</option>
            <option value="sendmail">Sendmail</option>
            <option value="mailgun">Mailgun</option>
            <option value="ses">Amazon SES</option>
          </select>
        </div>
        <Input
          label="From Email"
          type="email"
          value={settings.email_from || ''}
          onChange={(e) => handleChange('email_from', e.target.value)}
          placeholder="noreply@worksuite.com"
        />
        <Input
          label="From Name"
          value={settings.email_from_name || ''}
          onChange={(e) => handleChange('email_from_name', e.target.value)}
          placeholder="Worksuite CRM"
        />
        <Input
          label="SMTP Host"
          value={settings.smtp_host || ''}
          onChange={(e) => handleChange('smtp_host', e.target.value)}
          placeholder="smtp.gmail.com"
        />
        <Input
          label="SMTP Port"
          type="number"
          value={settings.smtp_port || 587}
          onChange={(e) => handleChange('smtp_port', parseInt(e.target.value))}
          placeholder="587"
        />
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">SMTP Encryption</label>
          <select
            value={settings.smtp_encryption || 'tls'}
            onChange={(e) => handleChange('smtp_encryption', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="tls">TLS</option>
            <option value="ssl">SSL</option>
            <option value="none">None</option>
          </select>
        </div>
        <Input
          label="SMTP Username"
          value={settings.smtp_username || ''}
          onChange={(e) => handleChange('smtp_username', e.target.value)}
          placeholder="your-email@gmail.com"
        />
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">SMTP Password</label>
          <div className="relative">
            <Input
              type={showPassword ? 'text' : 'password'}
              value={settings.smtp_password || ''}
              onChange={(e) => handleChange('smtp_password', e.target.value)}
              placeholder="Enter SMTP password"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 transform -translate-y-1/2 text-secondary-text hover:text-primary-text"
            >
              {showPassword ? <IoEyeOff size={20} /> : <IoEye size={20} />}
            </button>
          </div>
        </div>
      </div>
    </div>
  )
}

// Email Templates Settings Component
const EmailTemplatesSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Email Templates</h1>
        <p className="text-secondary-text">Manage email templates</p>
      </div>
      <div className="text-center py-8 text-secondary-text">
        <IoDocumentText size={48} className="mx-auto mb-2 text-gray-300" />
        <p>Email templates are managed in the Email Templates section</p>
        <Button
          variant="outline"
          onClick={() => window.location.href = '/app/admin/email-templates'}
          className="mt-4"
        >
          Go to Email Templates
        </Button>
      </div>
    </div>
  )
}

// Modules Settings Component
const ModulesSettings = ({ settings, handleChange }) => {
  const modules = [
    { key: 'module_leads', label: 'Leads' },
    { key: 'module_clients', label: 'Clients' },
    { key: 'module_projects', label: 'Projects' },
    { key: 'module_tasks', label: 'Tasks' },
    { key: 'module_invoices', label: 'Invoices' },
    { key: 'module_estimates', label: 'Estimates' },
    { key: 'module_proposals', label: 'Proposals' },
    { key: 'module_payments', label: 'Payments' },
    { key: 'module_expenses', label: 'Expenses' },
    { key: 'module_contracts', label: 'Contracts' },
    { key: 'module_subscriptions', label: 'Subscriptions' },
    { key: 'module_employees', label: 'Employees' },
    { key: 'module_attendance', label: 'Attendance' },
    { key: 'module_time_tracking', label: 'Time Tracking' },
    { key: 'module_events', label: 'Events' },
    { key: 'module_departments', label: 'Departments' },
    { key: 'module_positions', label: 'Positions' },
    { key: 'module_messages', label: 'Messages' },
    { key: 'module_tickets', label: 'Tickets' },
    { key: 'module_documents', label: 'Documents' },
    { key: 'module_reports', label: 'Reports' },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Modules Settings</h1>
        <p className="text-secondary-text">Enable or disable application modules</p>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {modules.map((module) => (
          <label
            key={module.key}
            className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors"
          >
            <input
              type="checkbox"
              checked={settings[module.key] !== false}
              onChange={(e) => handleChange(module.key, e.target.checked)}
              className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
            />
            <span className="text-sm font-medium text-primary-text">{module.label}</span>
            <Badge variant={settings[module.key] !== false ? 'success' : 'danger'} className="ml-auto">
              {settings[module.key] !== false ? 'Enabled' : 'Disabled'}
            </Badge>
          </label>
        ))}
      </div>
    </div>
  )
}

// Left Menu Settings Component
const LeftMenuSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Left Menu Settings</h1>
        <p className="text-secondary-text">Configure left sidebar menu</p>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Menu Style</label>
          <select
            value={settings.left_menu_style || 'default'}
            onChange={(e) => handleChange('left_menu_style', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="default">Default</option>
            <option value="compact">Compact</option>
            <option value="icon-only">Icon Only</option>
            <option value="collapsed">Collapsed</option>
          </select>
        </div>
        <div className="text-center py-8 text-secondary-text">
          <IoMenu size={48} className="mx-auto mb-2 text-gray-300" />
          <p>Menu items are managed in the sidebar configuration</p>
        </div>
      </div>
    </div>
  )
}

// Notifications Settings Component
const NotificationsSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Notifications Settings</h1>
        <p className="text-secondary-text">Configure notification preferences</p>
      </div>
      <div className="space-y-4">
        <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <input
            type="checkbox"
            checked={settings.email_notifications !== false}
            onChange={(e) => handleChange('email_notifications', e.target.checked)}
            className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-primary-text block">Email Notifications</span>
            <span className="text-xs text-secondary-text">Receive notifications via email</span>
          </div>
        </label>
        <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <input
            type="checkbox"
            checked={settings.sms_notifications === true}
            onChange={(e) => handleChange('sms_notifications', e.target.checked)}
            className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-primary-text block">SMS Notifications</span>
            <span className="text-xs text-secondary-text">Receive notifications via SMS</span>
          </div>
        </label>
        <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <input
            type="checkbox"
            checked={settings.push_notifications !== false}
            onChange={(e) => handleChange('push_notifications', e.target.checked)}
            className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-primary-text block">Push Notifications</span>
            <span className="text-xs text-secondary-text">Receive browser push notifications</span>
          </div>
        </label>
        <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <input
            type="checkbox"
            checked={settings.notification_sound !== false}
            onChange={(e) => handleChange('notification_sound', e.target.checked)}
            className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-primary-text block">Notification Sound</span>
            <span className="text-xs text-secondary-text">Play sound when notification arrives</span>
          </div>
        </label>
      </div>
    </div>
  )
}

// Integration Settings Component
const IntegrationSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Integration Settings</h1>
        <p className="text-secondary-text">Configure third-party integrations</p>
      </div>
      
      {/* Google Calendar */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <IoCalendar size={24} className="text-blue-600" />
            <div>
              <h3 className="text-lg font-semibold text-primary-text">Google Calendar</h3>
              <p className="text-sm text-secondary-text">Sync events with Google Calendar</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.google_calendar_enabled === true}
              onChange={(e) => handleChange('google_calendar_enabled', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-accent/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-accent"></div>
          </label>
        </div>
        {settings.google_calendar_enabled && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4 pt-4 border-t border-gray-200">
            <Input
              label="Client ID"
              value={settings.google_calendar_client_id || ''}
              onChange={(e) => handleChange('google_calendar_client_id', e.target.value)}
              placeholder="Enter Google Client ID"
            />
            <Input
              label="Client Secret"
              type="password"
              value={settings.google_calendar_client_secret || ''}
              onChange={(e) => handleChange('google_calendar_client_secret', e.target.value)}
              placeholder="Enter Google Client Secret"
            />
          </div>
        )}
      </Card>

      {/* Slack */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <IoNotifications size={24} className="text-purple-600" />
            <div>
              <h3 className="text-lg font-semibold text-primary-text">Slack</h3>
              <p className="text-sm text-secondary-text">Send notifications to Slack</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.slack_enabled === true}
              onChange={(e) => handleChange('slack_enabled', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-accent/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-accent"></div>
          </label>
        </div>
        {settings.slack_enabled && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <Input
              label="Webhook URL"
              value={settings.slack_webhook_url || ''}
              onChange={(e) => handleChange('slack_webhook_url', e.target.value)}
              placeholder="https://hooks.slack.com/services/..."
            />
          </div>
        )}
      </Card>

      {/* Zapier */}
      <Card className="p-4">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-3">
            <IoExtensionPuzzle size={24} className="text-orange-600" />
            <div>
              <h3 className="text-lg font-semibold text-primary-text">Zapier</h3>
              <p className="text-sm text-secondary-text">Connect with Zapier automation</p>
            </div>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={settings.zapier_enabled === true}
              onChange={(e) => handleChange('zapier_enabled', e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-11 h-6 bg-gray-200 peer-focus:outline-none peer-focus:ring-4 peer-focus:ring-primary-accent/20 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-primary-accent"></div>
          </label>
        </div>
        {settings.zapier_enabled && (
          <div className="mt-4 pt-4 border-t border-gray-200">
            <Input
              label="API Key"
              value={settings.zapier_api_key || ''}
              onChange={(e) => handleChange('zapier_api_key', e.target.value)}
              placeholder="Enter Zapier API Key"
            />
          </div>
        )}
      </Card>
    </div>
  )
}

// Cron Job Settings Component
const CronJobSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Cron Job Settings</h1>
        <p className="text-secondary-text">Configure automated tasks</p>
      </div>
      <div className="space-y-4">
        <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <input
            type="checkbox"
            checked={settings.cron_job_enabled !== false}
            onChange={(e) => handleChange('cron_job_enabled', e.target.checked)}
            className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-primary-text block">Enable Cron Jobs</span>
            <span className="text-xs text-secondary-text">Run automated tasks in the background</span>
          </div>
        </label>
        {settings.cron_job_enabled && (
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Frequency</label>
            <select
              value={settings.cron_job_frequency || 'daily'}
              onChange={(e) => handleChange('cron_job_frequency', e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
            >
              <option value="hourly">Hourly</option>
              <option value="daily">Daily</option>
              <option value="weekly">Weekly</option>
              <option value="monthly">Monthly</option>
            </select>
          </div>
        )}
        {settings.cron_job_last_run && (
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-secondary-text">
              Last Run: {new Date(settings.cron_job_last_run).toLocaleString()}
            </p>
          </div>
        )}
      </div>
    </div>
  )
}

// Updates Settings Component
const UpdatesSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Updates Settings</h1>
        <p className="text-secondary-text">Manage system updates</p>
      </div>
      <div className="space-y-4">
        <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
          <input
            type="checkbox"
            checked={settings.auto_update_enabled === true}
            onChange={(e) => handleChange('auto_update_enabled', e.target.checked)}
            className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
          />
          <div className="flex-1">
            <span className="text-sm font-medium text-primary-text block">Auto Update</span>
            <span className="text-xs text-secondary-text">Automatically install updates when available</span>
          </div>
        </label>
        {settings.auto_update_enabled && (
          <div>
            <label className="block text-sm font-medium text-primary-text mb-2">Update Channel</label>
            <select
              value={settings.update_channel || 'stable'}
              onChange={(e) => handleChange('update_channel', e.target.value)}
              className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
            >
              <option value="stable">Stable</option>
              <option value="beta">Beta</option>
              <option value="alpha">Alpha</option>
            </select>
          </div>
        )}
        {settings.last_update_check && (
          <div className="p-4 bg-gray-50 rounded-lg">
            <p className="text-sm text-secondary-text">
              Last Update Check: {new Date(settings.last_update_check).toLocaleString()}
            </p>
          </div>
        )}
        <Button
          variant="outline"
          onClick={() => handleChange('last_update_check', new Date().toISOString())}
          className="flex items-center gap-2"
        >
          <IoRefresh size={18} />
          Check for Updates
        </Button>
      </div>
    </div>
  )
}

// Access Permission Settings Component
const AccessPermissionSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Access Permission Settings</h1>
        <p className="text-secondary-text">Configure access permissions and role-based access control</p>
      </div>
      <div className="space-y-4">
        <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-sm text-blue-800">
            Access permissions are managed through the Roles & Permissions system. 
            Configure user roles and their permissions to control access to different features.
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Default Role</label>
          <select
            value={settings.default_role || 'employee'}
            onChange={(e) => handleChange('default_role', e.target.value)}
            className="w-full px-4 py-3 rounded-lg border border-gray-300 focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none"
          >
            <option value="admin">Admin</option>
            <option value="employee">Employee</option>
            <option value="client">Client</option>
          </select>
        </div>
        <div>
          <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
            <input
              type="checkbox"
              checked={settings.enable_two_factor === true}
              onChange={(e) => handleChange('enable_two_factor', e.target.checked)}
              className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
            />
            <div className="flex-1">
              <span className="text-sm font-medium text-primary-text block">Enable Two-Factor Authentication</span>
              <span className="text-xs text-secondary-text">Require 2FA for admin users</span>
            </div>
          </label>
        </div>
      </div>
    </div>
  )
}

// Client Portal Settings Component
const ClientPortalSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Client Portal Settings</h1>
        <p className="text-secondary-text">Configure client portal access and features</p>
      </div>
      <div className="space-y-4">
        <div>
          <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
            <input
              type="checkbox"
              checked={settings.client_portal_enabled === true}
              onChange={(e) => handleChange('client_portal_enabled', e.target.checked)}
              className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
            />
            <div className="flex-1">
              <span className="text-sm font-medium text-primary-text block">Enable Client Portal</span>
              <span className="text-xs text-secondary-text">Allow clients to access their portal</span>
            </div>
          </label>
        </div>
        {settings.client_portal_enabled && (
          <>
            <div>
              <label className="block text-sm font-medium text-primary-text mb-2">Portal URL</label>
              <Input
                type="text"
                value={settings.client_portal_url || ''}
                onChange={(e) => handleChange('client_portal_url', e.target.value)}
                placeholder="https://portal.example.com"
              />
            </div>
            <div>
              <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={settings.client_can_view_invoices === true}
                  onChange={(e) => handleChange('client_can_view_invoices', e.target.checked)}
                  className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
                />
                <div className="flex-1">
                  <span className="text-sm font-medium text-primary-text block">Allow Clients to View Invoices</span>
                </div>
              </label>
            </div>
            <div>
              <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
                <input
                  type="checkbox"
                  checked={settings.client_can_view_projects === true}
                  onChange={(e) => handleChange('client_can_view_projects', e.target.checked)}
                  className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
                />
                <div className="flex-1">
                  <span className="text-sm font-medium text-primary-text block">Allow Clients to View Projects</span>
                </div>
              </label>
            </div>
          </>
        )}
      </div>
    </div>
  )
}

// Sales & Prospects Settings Component
const SalesProspectsSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Sales & Prospects Settings</h1>
        <p className="text-secondary-text">Configure sales pipeline and prospect management</p>
      </div>
      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Default Sales Pipeline Stages</label>
          <div className="space-y-2">
            {['Lead', 'Qualified', 'Proposal', 'Negotiation', 'Closed Won', 'Closed Lost'].map((stage, index) => (
              <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded">
                <span className="text-sm text-primary-text">{stage}</span>
              </div>
            ))}
          </div>
        </div>
        <div>
          <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
            <input
              type="checkbox"
              checked={settings.auto_convert_lead === true}
              onChange={(e) => handleChange('auto_convert_lead', e.target.checked)}
              className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
            />
            <div className="flex-1">
              <span className="text-sm font-medium text-primary-text block">Auto Convert Leads to Clients</span>
              <span className="text-xs text-secondary-text">Automatically convert leads when they make a purchase</span>
            </div>
          </label>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Default Lead Source</label>
          <Input
            type="text"
            value={settings.default_lead_source || ''}
            onChange={(e) => handleChange('default_lead_source', e.target.value)}
            placeholder="Website, Referral, etc."
          />
        </div>
      </div>
    </div>
  )
}

// Setup Settings Component
const SetupSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Setup Settings</h1>
        <p className="text-secondary-text">Initial setup and configuration</p>
      </div>
      <div className="space-y-4">
        <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
          <p className="text-sm text-yellow-800">
            Setup wizard has been completed. You can modify these settings from their respective sections.
          </p>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">System Status</label>
          <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
            <div className="flex items-center gap-2">
              <IoCheckmarkCircle className="text-green-600" size={20} />
              <span className="text-sm text-green-800">System is fully configured and operational</span>
            </div>
          </div>
        </div>
        <div>
          <label className="block text-sm font-medium text-primary-text mb-2">Database Status</label>
          <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
            <span className="text-sm text-blue-800">Database connection is active</span>
          </div>
        </div>
      </div>
    </div>
  )
}

// Plugins Settings Component
const PluginsSettings = ({ settings, handleChange }) => {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-primary-text mb-2">Plugins Settings</h1>
        <p className="text-secondary-text">Manage installed plugins and extensions</p>
      </div>
      <div className="space-y-4">
        <div className="p-4 bg-gray-50 border border-gray-200 rounded-lg">
          <p className="text-sm text-secondary-text mb-4">No plugins installed</p>
          <Button variant="outline" className="flex items-center gap-2">
            <IoAdd size={18} />
            Install Plugin
          </Button>
        </div>
        <div>
          <label className="flex items-center gap-3 p-4 border border-gray-300 rounded-lg hover:bg-gray-50 cursor-pointer transition-colors">
            <input
              type="checkbox"
              checked={settings.auto_update_plugins === true}
              onChange={(e) => handleChange('auto_update_plugins', e.target.checked)}
              className="w-5 h-5 text-primary-accent rounded focus:ring-primary-accent"
            />
            <div className="flex-1">
              <span className="text-sm font-medium text-primary-text block">Auto Update Plugins</span>
              <span className="text-xs text-secondary-text">Automatically update plugins when new versions are available</span>
            </div>
          </label>
        </div>
      </div>
    </div>
  )
}

export default Settings
