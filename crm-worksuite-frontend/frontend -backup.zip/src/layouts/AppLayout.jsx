import { Outlet } from 'react-router-dom'
import { useState } from 'react'
import Sidebar from '../components/layout/Sidebar'
import TopBar from '../components/layout/TopBar'

const AppLayout = () => {
  const [sidebarOpen, setSidebarOpen] = useState(false)
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)

  return (
    <div className="min-h-screen bg-main-bg w-full overflow-x-hidden">
      <TopBar 
        onMenuClick={() => setSidebarOpen(true)} 
        isSidebarCollapsed={sidebarCollapsed}
        onToggleSidebar={() => setSidebarCollapsed(!sidebarCollapsed)}
      />
      <div className="flex relative w-full">
        <Sidebar
          isOpen={sidebarOpen}
          onClose={() => setSidebarOpen(false)}
          isCollapsed={sidebarCollapsed}
          onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
        />
        <div
          className={`flex-1 flex flex-col transition-all duration-300 ease-smooth min-h-screen w-full relative z-10 ${
            sidebarCollapsed 
              ? 'ml-0 lg:ml-20' 
              : 'ml-0 lg:ml-64'
          }`}
          style={{ paddingTop: '5rem' }}
        >
          <main className="flex-1 p-6 lg:p-8 xl:p-10 w-full max-w-full overflow-x-hidden relative z-10">
            <Outlet />
          </main>
        </div>
      </div>
    </div>
  )
}

export default AppLayout
