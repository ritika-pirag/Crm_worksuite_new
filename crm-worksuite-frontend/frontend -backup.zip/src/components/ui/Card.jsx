import React from 'react'

const Card = ({ children, className = '', onClick, ...props }) => {
  return (
    <div
      className={`bg-card-bg rounded-card shadow-card p-6 lg:p-8 ${onClick ? 'cursor-pointer hover:shadow-elevated transition-all duration-200' : ''} ${className}`}
      onClick={onClick}
      {...props}
    >
      {children}
    </div>
  )
}

export default Card
