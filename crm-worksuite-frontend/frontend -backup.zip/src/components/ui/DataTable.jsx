import React, { useState, useRef, useEffect } from 'react'
import { IoSearch, IoFilter, IoChevronBack, IoChevronForward, IoEllipsisVertical, IoClose, IoGrid } from 'react-icons/io5'

const DataTable = ({
  columns,
  data,
  searchPlaceholder = 'Search...',
  onSearch,
  filters,
  filterConfig = [], // Array of filter configs: { key, label, type: 'select'|'date'|'daterange'|'text', options: [] }
  onRowClick,
  actions,
  pagination = false,
  mobileColumns = 2, // Number of columns to show on mobile before "more"
  bulkActions = false,
  selectedRows: externalSelectedRows,
  onSelectAll: externalOnSelectAll,
}) => {
  const [searchTerm, setSearchTerm] = useState('')
  const [internalSelectedRows, setInternalSelectedRows] = useState([])
  const [expandedRow, setExpandedRow] = useState(null)
  const [showFilters, setShowFilters] = useState(false)
  const [showColumnToggle, setShowColumnToggle] = useState(false)
  const [activeFilters, setActiveFilters] = useState({})
  const [visibleColumns, setVisibleColumns] = useState(
    (columns || []).reduce((acc, col) => ({ ...acc, [col.key]: true }), {})
  )
  const columnToggleRef = useRef(null)
  
  const selectedRows = externalSelectedRows !== undefined ? externalSelectedRows : internalSelectedRows
  const setSelectedRows = externalSelectedRows !== undefined ? () => {} : setInternalSelectedRows

  // Close column dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (columnToggleRef.current && !columnToggleRef.current.contains(event.target)) {
        setShowColumnToggle(false)
      }
    }

    if (showColumnToggle) {
      document.addEventListener('mousedown', handleClickOutside)
    }

    return () => {
      document.removeEventListener('mousedown', handleClickOutside)
    }
  }, [showColumnToggle])

  const filteredData = (data || []).filter((row) => {
    // Search filter
    if (searchTerm) {
      const matchesSearch = Object.values(row).some((value) =>
        String(value || '').toLowerCase().includes(searchTerm.toLowerCase())
      )
      if (!matchesSearch) return false
    }

    // Advanced filters
    if (filterConfig && Array.isArray(filterConfig)) {
      for (const filter of filterConfig) {
        if (!filter || !filter.key) continue
        const filterValue = activeFilters[filter.key]
        if (filterValue === undefined || filterValue === '' || filterValue === null) continue

        if (filter.type === 'select') {
          if (row[filter.key] !== filterValue) return false
        } else if (filter.type === 'daterange') {
          if (!filterValue || (!filterValue.start && !filterValue.end)) continue
          const rowDateValue = row[filter.key]
          if (!rowDateValue) return false
          
          // Handle different date formats
          let rowDate
          if (typeof rowDateValue === 'string') {
            // Try to parse date string (could be ISO format or locale format)
            rowDate = new Date(rowDateValue)
          } else if (rowDateValue instanceof Date) {
            rowDate = rowDateValue
          } else {
            return false
          }
          
          if (isNaN(rowDate.getTime())) return false
          
          const startDate = filterValue.start ? new Date(filterValue.start) : null
          const endDate = filterValue.end ? new Date(filterValue.end) : null
          
          // Set time to start/end of day for proper comparison
          if (startDate) {
            startDate.setHours(0, 0, 0, 0)
            if (rowDate < startDate) return false
          }
          if (endDate) {
            endDate.setHours(23, 59, 59, 999)
            if (rowDate > endDate) return false
          }
        } else if (filter.type === 'date') {
          if (!filterValue) continue
          const rowDateValue = row[filter.key]
          if (!rowDateValue) return false
          
          const rowDate = new Date(rowDateValue)
          const filterDate = new Date(filterValue)
          
          if (isNaN(rowDate.getTime()) || isNaN(filterDate.getTime())) return false
          
          // Compare dates (ignore time)
          if (rowDate.toDateString() !== filterDate.toDateString()) return false
        } else if (filter.type === 'text') {
          if (!String(row[filter.key] || '').toLowerCase().includes(String(filterValue).toLowerCase())) return false
        }
      }
    }

    return true
  })

  const handleSearch = (e) => {
    const value = e.target.value
    setSearchTerm(value)
    if (onSearch) onSearch(value)
  }

  const handleSelectAll = (e) => {
    if (externalOnSelectAll) {
      externalOnSelectAll()
    } else {
      if (e.target.checked) {
        setInternalSelectedRows(filteredData.map((row) => row.id))
      } else {
        setInternalSelectedRows([])
      }
    }
  }

  const handleSelectRow = (id) => {
    if (externalSelectedRows === undefined) {
      setInternalSelectedRows((prev) =>
        prev.includes(id) ? prev.filter((r) => r !== id) : [...prev, id]
      )
    }
  }

  // Get primary columns for mobile view (first 2-3 columns)
  const primaryColumns = columns.slice(0, mobileColumns)
  const secondaryColumns = columns.slice(mobileColumns)

  return (
    <div className="bg-white rounded-card shadow-sm">
      {/* Search and Filters */}
      <div className="p-3 sm:p-4 border-b border-gray-200">
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3 sm:gap-4">
          <div className="flex-1 relative">
            <IoSearch className="absolute left-3 top-1/2 transform -translate-y-1/2 text-secondary-text" size={18} />
            <input
              type="text"
              placeholder={searchPlaceholder}
              value={searchTerm}
              onChange={handleSearch}
              className="w-full pl-10 pr-4 py-2.5 text-sm border border-border-medium rounded-input focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none transition-all duration-200 bg-white"
            />
          </div>
          
          {/* Filters Button - Always visible */}
          <button 
            onClick={() => setShowFilters(!showFilters)}
            className={`inline-flex items-center justify-center gap-2 px-3 py-2 border border-border-medium rounded-md hover:bg-sidebar-hover transition-all duration-200 text-sm whitespace-nowrap ${
              showFilters ? 'bg-sidebar-hover' : 'bg-white'
            }`}
          >
            <IoFilter size={16} />
            <span className="hidden sm:inline">Filters</span>
          </button>
          
          {/* Column Visibility Dropdown - Always visible */}
          <div className="relative" ref={columnToggleRef}>
            <button 
              onClick={() => setShowColumnToggle(!showColumnToggle)}
              className={`inline-flex items-center justify-center gap-2 px-3 py-2 border border-border-medium rounded-md hover:bg-sidebar-hover transition-all duration-200 text-sm whitespace-nowrap ${
                showColumnToggle ? 'bg-sidebar-hover' : 'bg-white'
              }`}
            >
              <IoGrid size={16} />
              <span className="hidden sm:inline">Columns</span>
            </button>
            
            {/* Column Visibility Dropdown Menu */}
            {showColumnToggle && (
              <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-elevated border border-border-light z-[60] max-h-96 overflow-y-auto">
                <div className="p-2">
                  <div className="px-3 py-2 text-xs font-semibold text-gray-500 uppercase tracking-wide border-b border-gray-200 mb-1">
                    Show Columns
                  </div>
                  <div className="space-y-1 mt-2">
                    {columns.map((col) => (
                      <label 
                        key={col.key} 
                        className="flex items-center gap-3 px-3 py-2 hover:bg-gray-50 rounded cursor-pointer transition-colors"
                      >
                        <input
                          type="checkbox"
                          checked={visibleColumns[col.key] !== false}
                          onChange={(e) => setVisibleColumns({ ...visibleColumns, [col.key]: e.target.checked })}
                          className="w-4 h-4 text-primary-accent rounded border-gray-300 focus:ring-primary-accent focus:ring-2"
                          onClick={(e) => e.stopPropagation()}
                        />
                        <span className="text-sm text-gray-700 flex-1">{col.label}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
        {bulkActions && selectedRows.length > 0 && (
          <div className="mt-3 p-3 bg-blue-50 border border-blue-200 rounded-lg">
            <p className="text-sm text-blue-800">
              {selectedRows.length} row(s) selected
            </p>
          </div>
        )}
        {showFilters && (
          <div className="mt-3 p-4 bg-gray-50 rounded-lg border border-gray-200">
            {filterConfig.length > 0 ? (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {filterConfig.map((filter) => (
                <div key={filter.key}>
                  <label className="block text-sm font-medium text-primary-text mb-1.5">
                    {filter.label}
                  </label>
                  {filter.type === 'select' && (
                    <select
                      value={activeFilters[filter.key] || ''}
                      onChange={(e) => setActiveFilters({ ...activeFilters, [filter.key]: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-border-medium rounded-input focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none transition-all duration-200 bg-white"
                    >
                      <option value="">All</option>
                      {filter.options?.map((opt) => (
                        <option key={typeof opt === 'object' ? opt.value : opt} value={typeof opt === 'object' ? opt.value : opt}>
                          {typeof opt === 'object' ? opt.label : opt}
                        </option>
                      ))}
                    </select>
                  )}
                  {filter.type === 'date' && (
                    <input
                      type="date"
                      value={activeFilters[filter.key] || ''}
                      onChange={(e) => setActiveFilters({ ...activeFilters, [filter.key]: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-border-medium rounded-input focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none transition-all duration-200 bg-white"
                    />
                  )}
                  {filter.type === 'daterange' && (
                    <div className="flex gap-2">
                      <div className="flex-1">
                        <label className="block text-xs text-secondary-text mb-1">Start Date</label>
                        <input
                          type="date"
                          value={activeFilters[filter.key]?.start || ''}
                          onChange={(e) => setActiveFilters({
                            ...activeFilters,
                            [filter.key]: { ...activeFilters[filter.key], start: e.target.value }
                          })}
                          className="w-full px-3 py-2 text-sm border border-border-medium rounded-input focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none transition-all duration-200 bg-white"
                        />
                      </div>
                      <div className="flex-1">
                        <label className="block text-xs text-secondary-text mb-1">End Date</label>
                        <input
                          type="date"
                          value={activeFilters[filter.key]?.end || ''}
                          onChange={(e) => setActiveFilters({
                            ...activeFilters,
                            [filter.key]: { ...activeFilters[filter.key], end: e.target.value }
                          })}
                          className="w-full px-3 py-2 text-sm border border-border-medium rounded-input focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none transition-all duration-200 bg-white"
                        />
                      </div>
                    </div>
                  )}
                  {filter.type === 'text' && (
                    <input
                      type="text"
                      placeholder={filter.placeholder || `Filter by ${filter.label}`}
                      value={activeFilters[filter.key] || ''}
                      onChange={(e) => setActiveFilters({ ...activeFilters, [filter.key]: e.target.value })}
                      className="w-full px-3 py-2 text-sm border border-border-medium rounded-input focus:ring-2 focus:ring-primary-accent focus:border-primary-accent outline-none transition-all duration-200 bg-white"
                    />
                  )}
                </div>
              ))}
              </div>
            ) : (
              <div className="text-center py-4">
                <p className="text-sm text-secondary-text">No filters configured for this table.</p>
                <p className="text-xs text-gray-400 mt-1">Contact administrator to add filters.</p>
              </div>
            )}
            {filterConfig.length > 0 && (Object.keys(activeFilters).length > 0 || Object.values(activeFilters).some(v => v !== '' && v !== null && (typeof v === 'object' ? (v.start || v.end) : true))) && (
              <div className="mt-4 flex items-center justify-between">
                <div className="flex flex-wrap gap-2">
                  {Object.entries(activeFilters).map(([key, value]) => {
                    if (!value || value === '' || (typeof value === 'object' && !value.start && !value.end)) return null
                    const filter = filterConfig.find(f => f.key === key)
                    if (!filter) return null
                    return (
                      <span
                        key={key}
                        className="inline-flex items-center gap-1.5 px-3 py-1 bg-primary-accent bg-opacity-10 text-primary-accent rounded-full text-xs"
                      >
                        {filter.label}: {typeof value === 'object' ? `${value.start || ''} - ${value.end || ''}` : value}
                        <button
                          onClick={() => {
                            const newFilters = { ...activeFilters }
                            delete newFilters[key]
                            setActiveFilters(newFilters)
                          }}
                          className="hover:text-primary-accent"
                        >
                          <IoClose size={14} />
                        </button>
                      </span>
                    )
                  })}
                </div>
                <button
                  onClick={() => setActiveFilters({})}
                  className="text-sm text-danger hover:underline"
                >
                  Clear All
                </button>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Desktop Table View */}
      <div className="hidden md:block overflow-x-auto">
        <table className="w-full">
          <thead className="bg-main-bg border-b border-gray-200">
            <tr>
              {(actions || bulkActions) && (
                <th className="px-3 lg:px-4 py-3 text-left">
                  <input
                    type="checkbox"
                    checked={selectedRows.length === filteredData.length && filteredData.length > 0}
                    onChange={handleSelectAll}
                    className="rounded border-gray-300"
                  />
                </th>
              )}
              {columns.filter(col => visibleColumns[col.key] !== false).map((col) => (
                <th
                  key={col.key}
                  className="px-3 lg:px-4 py-3 text-left text-xs lg:text-sm font-semibold text-primary-text whitespace-nowrap"
                >
                  {col.label}
                </th>
              ))}
              {actions && (
                <th className="px-3 lg:px-4 py-3 text-right text-xs lg:text-sm font-semibold text-primary-text">
                  Actions
                </th>
              )}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-200">
            {filteredData.length === 0 ? (
              <tr>
                <td
                  colSpan={columns.length + ((actions || bulkActions) ? 2 : 0)}
                  className="px-4 py-8 text-center text-secondary-text"
                >
                  No data found
                </td>
              </tr>
            ) : (
              filteredData.map((row, index) => (
                <tr
                  key={row.id || row.company_id || `row-${index}`}
                  onClick={() => onRowClick && onRowClick(row)}
                  className={`hover:bg-main-bg transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
                >
                  {(actions || bulkActions) && (
                    <td className="px-3 lg:px-4 py-3">
                      <input
                        type="checkbox"
                        checked={selectedRows.includes(row.id)}
                        onChange={() => handleSelectRow(row.id)}
                        onClick={(e) => e.stopPropagation()}
                        className="rounded border-gray-300"
                      />
                    </td>
                  )}
                  {columns.filter(col => visibleColumns[col.key] !== false).map((col, colIndex) => (
                    <td key={`${row.id}-${col.key}-${colIndex}`} className="px-3 lg:px-4 py-3 text-xs lg:text-sm text-secondary-text">
                      {col.render ? col.render(row[col.key], row) : row[col.key]}
                    </td>
                  ))}
                  {actions && (
                    <td className="px-3 lg:px-4 py-3 text-right" onClick={(e) => e.stopPropagation()}>
                      {actions(row)}
                    </td>
                  )}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Mobile Card View */}
      <div className="md:hidden divide-y divide-gray-200">
        {filteredData.length === 0 ? (
          <div className="p-6 text-center text-secondary-text">
            No data found
          </div>
        ) : (
          filteredData.map((row, index) => (
            <div
              key={row.id || row.company_id || `row-${index}`}
              className={`p-4 hover:bg-main-bg transition-colors ${onRowClick ? 'cursor-pointer' : ''}`}
              onClick={() => onRowClick && onRowClick(row)}
            >
              {/* Primary Info */}
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  {primaryColumns.map((col, idx) => (
                    <div key={col.key} className={idx === 0 ? 'mb-1' : ''}>
                      {idx === 0 ? (
                        <div className="font-semibold text-primary-text text-sm truncate">
                          {col.render ? col.render(row[col.key], row) : row[col.key]}
                        </div>
                      ) : (
                        <div className="text-xs text-secondary-text truncate">
                          {col.render ? col.render(row[col.key], row) : row[col.key]}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
                {actions && (
                  <div onClick={(e) => e.stopPropagation()} className="flex-shrink-0">
                    {actions(row)}
                  </div>
                )}
              </div>

              {/* Secondary Info - Expandable */}
              {secondaryColumns.length > 0 && (
                <div className="mt-3 pt-3 border-t border-gray-100">
                  <div className="grid grid-cols-2 gap-2">
                    {secondaryColumns.map((col) => (
                      <div key={col.key} className="min-w-0">
                        <div className="text-[10px] uppercase text-muted-text tracking-wide">{col.label}</div>
                        <div className="text-xs text-secondary-text truncate mt-0.5">
                          {col.render ? col.render(row[col.key], row) : row[col.key]}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ))
        )}
      </div>

    </div>
  )
}

export default DataTable
