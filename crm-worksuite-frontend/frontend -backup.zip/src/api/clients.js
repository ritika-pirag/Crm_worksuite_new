import axiosInstance from './axiosInstance'

export const clientsAPI = {
  getAll: (params) => axiosInstance.get('/clients', { params }),
  getById: (id, params) => axiosInstance.get(`/clients/${id}`, { params }),
  create: (data) => axiosInstance.post('/clients', data),
  update: (id, data) => axiosInstance.put(`/clients/${id}`, data),
  delete: (id, params) => axiosInstance.delete(`/clients/${id}`, { params }),
  getOverview: (params) => axiosInstance.get('/clients/overview', { params }),
  addContact: (id, data, params) => axiosInstance.post(`/clients/${id}/contacts`, data, { params }),
  getContacts: (id, params) => axiosInstance.get(`/clients/${id}/contacts`, { params }),
  updateContact: (clientId, contactId, data) => axiosInstance.put(`/clients/${clientId}/contacts/${contactId}`, data),
  deleteContact: (clientId, contactId) => axiosInstance.delete(`/clients/${clientId}/contacts/${contactId}`),
}

